import java.util.Scanner;

public class Exercise {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		String firstName,lastName,city;
		int zip;
		System.out.println("Enter your firstName:");
		firstName = input.next();
		System.out.println("Enter your lastName:");
		lastName = input.next();
		System.out.println("Enter your city:");
		city = input.next();
		System.out.println("Enter your zip:");
		zip = input.nextInt();
		System. out .printf("First Name \tLast Name\tCity\n");  
		System. out .printf("----------- \t---------\t---\n");   
		System. out .printf(firstName+"\t"+lastName+"\t"+city+"\t"+zip); 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
